# Trix AI

Android voice assistant prototype.

- Minimum Android version: Android 10 (API 29)
- Target Android version: Android 15 (API 35)
- Java/Kotlin JVM target: 17
- Build: GitHub Actions

Note: Gemini API keys should be supplied securely at runtime; do not commit secrets.
