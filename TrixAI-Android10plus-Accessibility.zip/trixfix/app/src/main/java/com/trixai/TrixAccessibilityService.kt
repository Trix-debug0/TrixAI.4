package com.trixai

import android.accessibilityservice.AccessibilityService
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class TrixAccessibilityService : AccessibilityService() {
    private var tts: TextToSpeech? = null
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    fun readCurrentScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val parts = mutableListOf<String>(); collectText(root, parts)
        return parts.distinct().joinToString(". ").trim()
    }
    fun speakCurrentScreen(): String {
        val text = readCurrentScreen()
        speak(if (text.isBlank()) "I couldn't find readable text on this screen." else text.take(3500)); return text
    }
    fun clickText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return clickNode(findNodeByText(root, label))
    }
    private fun findNodeByText(node: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val wanted = label.trim().lowercase(Locale.ROOT)
        val text = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
        if (wanted.isNotBlank() && (text == wanted || desc == wanted)) return node
        for (i in 0 until node.childCount) { node.getChild(i)?.let { findNodeByText(it, label)?.let { f -> return f } } }
        return null
    }
    private fun clickNode(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return clickNode(node.parent)
    }
    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectText(it, out) }
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "trix_accessibility") }
    override fun onDestroy() { if (instance === this) instance = null; tts?.stop(); tts?.shutdown(); tts = null; super.onDestroy() }
    companion object { @Volatile var instance: TrixAccessibilityService? = null; private set }
}
